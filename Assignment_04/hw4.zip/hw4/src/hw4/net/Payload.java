package hw4.net;

public class Payload {

}
