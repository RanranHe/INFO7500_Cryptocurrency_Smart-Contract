package hw4.consensus.bft;

import hw4.net.Message;
import hw4.net.Send;
import hw4.net.Node;

import java.util.*;

public class UnauthBFTNode extends Node {
    private EIGTree tree;

    public UnauthBFTNode() {
    }

    @Override
    public List<Send> send(int round) {
        //look the level ROUND-1 in the tree
        //for each vertex V in that level, create a message that sends the label
        //    of V to every other node in the network
        return Collections.EMPTY_LIST;
    }

    @Override
    public void receive(int round, List<Message> messages) {
        //for each message, find the vertex V in level ROUND of tree,
        // and set the label of vertex indicated in the message
    }

    @Override
    public void commit() {

    }
}
